/** i am using the new method: Integer.parseInt()
    Integer.toString()  
    **/
import java.util.Scanner;
public class CreditCardCheck
{
   public static void main (String[] args)
   { Scanner reader = new Scanner(System.in);
     System.out.print("Enter 8 digit credit card number: ");
     String userInput = reader.nextLine();
     String seperatePut = "";
     String lastSeperatePut = "";
     String countHelper2 = "";
     String helper3 = "";
     String helper4 = "";
     int upperCount = 0;
     int lowerCount = 0;
     int countHelper = 0;
     int finalShot = 0;
     for ( int x = 7; x > 0; x -= 2)
     { 
       seperatePut = userInput.substring( x , x + 1 );
       upperCount += Integer.parseInt(seperatePut);
       lastSeperatePut = userInput.substring( x - 1 , x );
       countHelper = Integer.parseInt(lastSeperatePut) * 2;
       for ( int y = 0; y < Integer.toString(countHelper).length(); y++ )
       {    countHelper2 = (Integer.toString(countHelper)).substring(y , y + 1);
            lowerCount += Integer.parseInt(countHelper2);}
      }
     int totalCount = upperCount + lowerCount;
     String tfnc = "";
     tfnc = Integer.toString(totalCount);
     if ( (tfnc.substring(tfnc.length() - 1, tfnc.length() )).equals("0") )
     { System.out.println("The credit card number is valid.");
        }
     else
     {  helper3 = (Integer.toString(upperCount));
        helper4 = (Integer.toString(lowerCount));
        finalShot = 10 - (Integer.parseInt(helper3.substring(helper3.length() - 1)) + Integer.parseInt(helper4.substring(helper4.length() - 1)));
        System.out.println("The credit card number is not valid.");
        System.out.println("The last digit should be " + (Integer.parseInt(userInput.substring(userInput.length() - 1)) + finalShot));}
   }
}