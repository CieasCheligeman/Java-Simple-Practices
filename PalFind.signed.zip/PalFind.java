import java.util.Scanner;

/**
   Reads a string, checks to see if it is a palindrome, and prints
      "Yes" or "No", accordingly. 
   Input: the value of s, a string
   Output: "Yes" or "No"
*/
public class PalFind
{
   public static void main(String[] args)
   {
      // Read string and convert to lowercase
      Scanner in = new Scanner(System.in);
      String ins = in.nextLine();
      ins = ins.toLowerCase();

      int a = 1;
      int b = 0;
      String p = "";

      for ( int times = 0; times < ins.length(); times ++ )
         { p = p + ins.substring(ins.length() - a, ins.length() - b); 
           b ++ ;
           a ++ ;}
           
      if ( p.equals(ins) )
         System.out.println("Yes");
      else
         System.out.println("No");




   }
}