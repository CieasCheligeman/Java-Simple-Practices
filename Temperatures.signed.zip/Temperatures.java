import java.util.Scanner;

/**
   A program that reads in a temperature in degrees that may
      be Fahenheit or may be Celsius.  The second input value
      is the string "F" for Fahrenheit or "C" for Celsius.
      If the string is an "F", the temperature read was
      Farhenheit, which needs to be converted to Celsius.
      If the string is an "C", the temperature read was
      Celsius, which needs to be converted to Fahrenheit.
      The converted temperature is then printed.
*/
public class Temperatures
{
   public static void main (String[] args)
   {
      // Define constants

      // Your work here

      // Display prompt for temperature in degrees Farhenheit or Celsius
      System.out.println("Please enter the temperature in degrees: ");

      // Read temperature
      Scanner in = new Scanner(System.in);
      double temp = in.nextDouble();
      double convertedTemp;

      // Display prompt for character that denotes type of temperature
      System.out.println("Enter F for Farhenheit or C for Celsius: ");

      // Read character denoting type of temperature
      String type = in.next();

      // Compute and print Celsius or Farhenheit equivalent

      // Your work here
      if ( type.equals("F") )
      {convertedTemp = (5.0 / 9.0) * (temp - 32.0);
      type = "Celsius:";}
      else
      {convertedTemp = ((9.0 / 5.0) * temp) + 32.0;
      type = "Farhenheit:";}
      


      System.out.println(type + "  " + convertedTemp);
   }
}