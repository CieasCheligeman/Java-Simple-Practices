import java.util.ArrayList;

public class ArrayOps
{
   /**
       This method goes through the array of integers identified by
       the only parameter, creating a new ArrayList from the array,
       eliminating duplicates from the original array.
       @param theArray, an array of integer
       @return the new ArrayList

   */
   public static ArrayList copyArray(int[] anArray)
   {
      // your work here
      int k = 0;
      int d = 0;
      ArrayList<Integer> unique = new ArrayList<Integer>();
      for (int i = 0; i < anArray.length; i ++)
           unique.add(anArray[i]);
           
      for (int a = 0; a < unique.size(); a++)
          {k = unique.get(a);
           d = 0;
           for (int c = 0; c < unique.size(); c ++)
           {    if ( k == unique.get(c) )
                {d ++;
                 if (d >= 2)
                     {unique.remove(c);
                      c --;}
                        
                }
           }
          }
      return unique;

   }}