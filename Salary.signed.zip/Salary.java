/**
   A salary to which a bonus can be applied.
*/
public class Salary
{
   private double value;
   public Salary(double b){
      value = b;
   }
   public void applyBonus(double bonus)
   {
      value = value * (1 + bonus);
   }
   public double getValue()
   {
      return value;
   }
   
}