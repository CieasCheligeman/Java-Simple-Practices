public class ReplacementTester
{
   public static void main(String[] args)
   {
      String greeting = "Hello, elite hacker!";
      greeting = greeting.replace("e","3");
      greeting = greeting.replace("i","1");
      greeting = greeting.replace("l","7");
      greeting = greeting.replace("o","0");
      String modifiedGreeting = greeting;

      System.out.println(modifiedGreeting);
      System.out.println("Expected: H3770, 371t3 hack3r!");
   }
}