public class ArrayOps
{
   /**
      This method sums up both rows of a two-dimensional array
      (the only parameter to the method) and returns the greater sum.
      @param theArray, a 2-D array of integers
      @return, the greater row sum
   */
   public static int bigSum(int[][] theArray)
   {
      // your work here
      int counter = 0;
      // loop though theArray, summing first row
      for ( int i = 0; i < theArray[0].length; i++)
            counter += theArray[0][i];

      // your work here
      int counter2 = 0;
      // loop though theArray, summing second row 
      for ( int i = 0; i < theArray[1].length; i++)
            counter2 += theArray[1][i];
      // your work here
      int finalCount = Math.max(counter,counter2);
      // return larger sum
      return finalCount;
      // your work here

   }
}