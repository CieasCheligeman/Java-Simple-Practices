import java.util.Scanner;

/** 
   This program reads a price in dollars and cents,
   rounds the price to the nearest dime,
   and prints out the revised price.
*/
public class NearestDime
{
   public static void main(String[] args)
   {
      System.out.print("Please enter the price: ");
      Scanner in = new Scanner(System.in);
      double price = in.nextDouble();
      int pennies = (int) Math.round(price * 100);

      // Determine dollar and cents worth of pennies 
      double cents;
      int dollars;

      // Your work here
      cents = pennies / 10.0; 
      dollars = pennies / 100;

      // Round cents to nearest dime
      double dimes;

      // Your work here
      dimes = Math.round(cents - dollars * 10);

      // Print revised price
      double revised = dollars + dimes * 0.1;
      System.out.printf("%.2f\n", revised);      
   }
}