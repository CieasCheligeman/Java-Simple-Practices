/** 
   A program to print two lines
*/

public class HelloAll
{
   public static void main(String[] args)
   {
      System.out.println("Hello, World!");

      System.out.println("Hello, All!");
   }
}