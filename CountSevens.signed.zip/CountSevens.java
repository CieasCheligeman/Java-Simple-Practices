import java.util.Scanner;

/**
   Counts the number of digits with value 7 in the decimal 
   representation of the integer n
*/
public class CountSevens
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
      int n = in.nextInt();
      int count = 0;
      int i = 0;
      int redefine = n;
      /* for the first time, i = 0
      ex: 123 / 1 = 12[3]
          123 / 10 = 1[2]
          123 / 100 = [1]
          It goes with this process at total three times which is matching up the number of the digit
          PS: [x] means it is the result for the if statement of n - x/10*10.
      */
      while ( n / Math.pow(10,i) > 0 )
      { if ((redefine - ((redefine / 10) * 10)) - 7 == 0)
           count = count + 1;
      // for avoiding repeated counting
           redefine = redefine / 10;
        i++;}



      System.out.println(count);
   }
}