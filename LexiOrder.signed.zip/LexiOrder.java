import java.util.Scanner;

/** 
   A program reads two integer values
   and prints out the larger of the two.
   If the values are equal, only one of the value is printed.
*/
public class LexiOrder
{
   public static void main(String[] args)
   {
      // Print prompt to enter two words (strings)
      System.out.println("Please enter two words: ");

      // Read in both integer values
      Scanner in = new Scanner(System.in);
      String word1 = in.next();
      String word2 = in.next();

      // Determine the correct alphabetical order of words
      // and print out the words in one line, in order.

      // Your work here
      if ( word1.compareTo(word2) > 0)
      System.out.println(word2 +" " + word1);
      if ( word1.compareTo(word2) < 0)
      System.out.println(word1 +" " + word2);
      if ( word1.compareTo(word2) == 0)
      System.out.println(word1);


   }
}