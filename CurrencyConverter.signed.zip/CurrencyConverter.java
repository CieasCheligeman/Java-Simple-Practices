import java.util.Scanner;
public class CurrencyConverter
{
   public static void main (String[] args)
   { Scanner reader = new Scanner(System.in);
     System.out.print("How many euros is one dollar: ");
     double i = reader.nextDouble();
     int x = 1;
     double p = 0;
     double d = 0;
     while ( x == 1 )
     {   System.out.print("Dollar value (Q to quit): ");
         String j = reader.next();
         if ( j.equals("Q") )
         x = 0; 
         else
         {d = Double.parseDouble(j);
          p = Math.round(d * i * 100.0) / 100.0;
          System.out.println(d + " dollar = " + p + " euro");}
     }
   }
}