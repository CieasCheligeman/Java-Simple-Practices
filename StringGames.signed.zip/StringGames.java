import java.util.Scanner;

/**
   A program reads in a string,
   prints out the last character of the string,
   followed by the first character, and then
   followed by the middle three characters of the string.
   All input strings should be of odd length.
*/
public class StringGames
{
   public static void main (String[] args)
   {
      // Display prompt for input string
      System.out.println("Please enter a string: ");

      // Read string
      Scanner in = new Scanner(System.in);
      String input = in.next();
      String lCharac = input.substring(input.length() - 1);
      String fCharac = input.substring(0,1);
      String mCharac = input.substring(input.length() / 2 - 1, input.length() / 2 + 2 );

      // Put together new string and print
      String output = lCharac + fCharac + mCharac;

      // Your work here
      System.out.println(output);
   }
}