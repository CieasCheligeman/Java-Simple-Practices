import java.util.Scanner;

/**
   A program that reads in a temperature in degrees Fahenheit
      and converts it to the equivalent temperature in Celsius
      and also the equivalent temperature in Kelvin.
   For example, if the input is F = 68.0 degrees Fahrenheit,
      then the conversions should show that C = 20.0 degrees Celsius
      and K = 293.0 degrees Kelvin.
*/
public class ConvertTemp
{
   public static void main (String[] args)
   {
      // Define constants
      final double thisIs5 = 5.0;
      final double thisIs9 = 9.0;
      final double ohMy32 = 32.0;
      final double theKey273 = 273.0;

      System.out.print("Please enter the temperature ");
      System.out.println("in degrees Farhenheit: ");

      Scanner in = new Scanner(System.in);
      double f = in.nextDouble();
      
      double c = (thisIs5 / thisIs9) * (f - ohMy32);
      double k = c + theKey273;
      System.out.println(c);
      System.out.println(k);
   }
}