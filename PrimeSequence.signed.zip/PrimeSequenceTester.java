public class PrimeSequenceTester{
   public static void main(String args[]){
   PrimeSequence d = new PrimeSequence(7919);
   for (int i = 0; i < 7919; i ++){
      int a = d.next();
      if(a == 2){
         System.out.println(a);
         System.out.println("Expected: 2");
      }
      if(a == 3){
         System.out.println(a);
         System.out.println("Expected: 3");
      }
      if(a == 7919){
         System.out.println(a);
         System.out.println("Expected: 7919");
         break;
      }
   }
   }
}