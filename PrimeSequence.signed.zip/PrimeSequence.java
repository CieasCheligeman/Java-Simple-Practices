public class PrimeSequence implements Sequence
{
   private int[] c;
   private int counter1;
   private int counter3;
   public PrimeSequence(){
      int counter2 = 0;
      int i = 0;
      int k = 0;
      int y = 0;
      c = new int[1000];
      while ( counter2 < 1000 ){
         k ++;
         for (int p = 1; p <= k ; p++){
            if ( k % p == 0){
               y++;
            }}
         if ( y == 2 ){
               c[i] = k;
               counter2 ++;
               i ++;
         }
         y = 0;
      }
   }
   public int next(){
      if ( counter1 == 0 ){
         counter1 ++;
         return c[counter1 - 1];
      }
      counter3 ++;
      return c[counter3];
}
    public PrimeSequence(int num){
      int counter2 = 0;
      int i = 0;
      int k = 0;
      int y = 0;
      c = new int[num];
      while ( counter2 < num ){
         k ++;
         for (int p = 1; p <= k ; p++){
            if ( k % p == 0){
               y++;
            }}
         if ( y == 2 ){
               c[i] = k;
               counter2 ++;
               i ++;
         }
         y = 0;
      }
   }
}