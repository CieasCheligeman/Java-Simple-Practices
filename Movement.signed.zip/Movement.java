/**
   Implements a generalized interface for
   types of movement by objects.
*/

   // TODO: create the interface type and the abstract methods move and getPosition
   public interface Movement{
      void move(int distant);
      String getPosition();
   }
   // to support the Ship and Auto classes.