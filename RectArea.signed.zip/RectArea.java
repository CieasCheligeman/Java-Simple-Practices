/**
   A program that computes the area of a rectangle
   and prints it out.
   All variables should be of type double.
*/
public class RectArea
{
   public static void main (String[] args)
   {
      double width = 4.25;
      double height = 3.40;
      
      double area;
      area = width * height;

      System.out.println(area);

   }
}