import java.util.Scanner;

/** 
   This program reads information about coins and 
   prints the value of the coins.
*/
public class Coins
{
   public static void main(String[] args)
   {
      // Define constants
      final String P_TYPE = "P";
      final String N_TYPE = "N";
      final String D_TYPE = "D";
      final String Q_TYPE = "Q";
      double value = 0;

      // Read a number and type of coin 
      System.out.println("Enter number and type of coins: ");

      Scanner in = new Scanner(System.in);
      int numCoins = in.nextInt();
      String typCoin = in.next();

      // Determine and print worth of coin pile
      if ( typCoin.equals("P") )
      {value = numCoins / 100.0;
      System.out.print(value);}
      if ( typCoin.equals("N") )
      {value = numCoins * 5 / 100.0;
      System.out.print(value);}
      if ( typCoin.equals("D") )
      {value = numCoins * 10 / 100.0;
      System.out.print(value);}
      if ( typCoin.equals("Q") )
      {value = numCoins * 25 / 100.0;
      System.out.print(value);}
      if ( "PNDQ".indexOf(typCoin.toUpperCase()) == -1 )
      System.out.println("Error");

      // Use output statements


   }
}