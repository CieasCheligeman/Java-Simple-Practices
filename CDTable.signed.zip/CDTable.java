import java.util.Scanner;

/**
   A program that reads in an interest rate and creates a table of
   future values of a one-thousand dollar certificate of deposit
   for that interest rate and different numbers of years.
   All variables should be of type double, except for the number of years.
*/
public class CDTable
{
   public static void main (String[] args)
   {
      // Display prompt for interest rate
      System.out.print("Please enter the rate of interest: ");

      // Read interest rate
      Scanner in = new Scanner(System.in);
      double rate = in.nextDouble();
      /** Without using for loops ————————————————————————
         the only way for us to do this question might be just copying and pasting
         Sorry about these tons of mass.
      */
         
      int years = 0;
      int years2 = 5;
      int years3 = 10;
      int years4 = 15;
      int years5 = 20;
      int years6 = 25;
      double pV = 1000.00;
      double fV = pV * Math.pow((1.00 + rate / 100.00), years);
      double fV2 = pV * Math.pow((1.00 + rate / 100.00), years2);
      double fV3 = pV * Math.pow((1.00 + rate / 100.00), years3);
      double fV4 = pV * Math.pow((1.00 + rate / 100.00), years4);
      double fV5 = pV * Math.pow((1.00 + rate / 100.00), years5);
      double fV6 = pV * Math.pow((1.00 + rate / 100.00), years6);
      
      System.out.printf("%2d %7.2f\n", years, fV);
      System.out.printf("%2d %7.2f\n", years2, fV2);
      System.out.printf("%2d %7.2f\n", years3, fV3);
      System.out.printf("%2d %7.2f\n", years4, fV4);
      System.out.printf("%2d %7.2f\n", years5, fV5);
      System.out.printf("%2d %7.2f\n", years6, fV6);

   }
}