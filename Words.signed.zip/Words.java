public class Words
{
   /**
      Computes a string that repeats every letter 't' in the original string.
      @param s any string
      @return a string with the same characters as s, except that every letter 't' is repeated
   */
   public String stutter(String s)
   {
      // your work here
      String r = "";
      for  ( int a = 0 ; a < s.length() ; a ++ )
         { if (s.substring(a , a + 1).equals("t"))
               r = r.substring(0) + s.substring(a, a + 1) + "t";
           else
               r = r.substring(0) + s.substring(a, a + 1);

               
           }
           return r;
   
   
   
   
   
   }
}