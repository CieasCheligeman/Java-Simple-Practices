/**
   A program to print algebraic expressions
*/

public class Algebra
{
   public static void main(String[] args)
   {

      System.out.println("Given: f(x) = 3x - 15");
      System.out.println("Let x = 4");
      System.out.println("Then");
      System.out.println("  f(4) = 3x4 - 15");
      System.out.println("       = 12 - 15");
      System.out.println("       = -3");

   }
}