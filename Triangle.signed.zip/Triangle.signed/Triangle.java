/** 
   A program to draw a filled triangle.
*/

public class Triangle
{
   public static void main(String[] args)
   {
      System.out.println("   x");
      System.out.println("  xxx");
      System.out.println(" xxxxx");
      System.out.println("xxxxxxx");
      

   }
}