import java.util.Scanner;

/**
   A program that reads in a first name, a middle name, and a last name,
      and then print out the three initials as a single string.
   For example, if the three input names are James, Paul, and Jones,
      then the output should be JPJ.
*/
public class Initials
{
   public static void main (String[] args)
   {
      // Display prompts for all three names
      System.out.println("Please enter first name, middle name, last name: ");

      // Read names
      Scanner in = new Scanner(System.in);
      String fName = in.next();
      String mName = in.next();
      String lName = in.next();

      // Print out the initials 
      fName = fName.substring(0,1);
      mName = mName.substring(0,1);
      lName = lName.substring(0,1);
      String output = fName + mName + lName;

      // Your work here
      System.out.println(output);

   }
}