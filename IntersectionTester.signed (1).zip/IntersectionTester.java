import java.awt.Rectangle;

public class IntersectionTester
{
   public static void main(String[] args)
   {
      Rectangle box1 = new Rectangle(5, 10, 20, 30);
      Rectangle box2 = new Rectangle(10, 15, 20, 30);
      // now translate box2
      /** This is the testing process:
      * Rectangle box1 = new Rectangle(5, 10, 20, 30);
      * Rectangle box2 = new Rectangle(10, 15, 20, 30);
      * box2.translate(5,15);
      * box1.draw();
      * box2.draw(); notation:the plenty of stars was for the beauty of looking...
      * And on more thing:! the y position is going downword! 
      */
      box2.translate(5,15);
      Rectangle box = box1.intersection(box2);
      double area = box.getWidth() * box.getHeight();
      System.out.println(area);
      System.out.println("Expected: 100");
   }
}