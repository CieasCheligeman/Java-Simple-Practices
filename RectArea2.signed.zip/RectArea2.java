import java.util.Scanner;

/**
   A program that prompts for the height and width of a rectangle
   and prints the area of that rectangle.  
   All variables should be of type double.
*/
public class RectArea2
{
   public static void main (String[] args)
   {
      Scanner cieas = new Scanner(System.in);
      
      // Display prompt for rectangle width
      System.out.print("Please enter the width of the rectangle: ");

      // Read width of rectangle
      double width = cieas.nextDouble();
      
      // Display prompt for rectangle height
      System.out.print("Please enter the height of the rectangle: ");

      double height = cieas.nextDouble();
      
      double area = width * height;
      
      System.out.println(area);
   }
}