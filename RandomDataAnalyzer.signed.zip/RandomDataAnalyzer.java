
public class RandomDataAnalyzer
{
   public static void main (String[] args)
   { int x = 0;
     int y = 0;
     int c = 0;
     double countAverage = 0;
     int maximum = 0;
     for ( int i = 0; i < 100; i ++ )
        { x = (int)(Math.random() * 1000);
          y += x;
          if ( c < x )
          { maximum = x;
            }
          /** last time count **/
          c = x;
     }
     countAverage = y / 100.0;
     System.out.println(maximum);
     System.out.println(countAverage);
}
}