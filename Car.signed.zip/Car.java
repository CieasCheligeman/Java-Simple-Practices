/**
   Represents a car.
*/
public class Car extends Vehicle// TODO: Inherit from Vehicle
{
   // Do NOT add any instance variables

   public Car(double purchasePrice)
   {
      // TODO: Complete
      super(purchasePrice);
   }

   // TODO: Override the getValue method
   public double getValue()
   {
      double value = super.getValue();
      
      value -= (super.getMileage() / 10000.0) * 2500.0;
      if ( value < 0 )
         value = 0;
      return value;
   }
}