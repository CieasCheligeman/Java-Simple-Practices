import java.util.Scanner;

/**
   Reads a string, reverses the order the characters within the
   string, and prints out the result.
   Input: the value of s, a string
   Output: the string reversed
*/
public class ReverseString
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
      String s = in.nextLine();
      int a = 1;
      int b = 0;

      // your work here
      for ( int times = 0; times < s.length(); times ++ )
         { System.out.print( s.substring(s.length() - a, s.length() - b) ); 
           b ++ ;
           a ++ ; }
      



   }
}