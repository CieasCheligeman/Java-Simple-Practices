/**
   Represents an automobile.
*/
public class Auto extends Vehicle// TODO: Inherit from Vehicle
{
   // TODO: Declare instance variables
   private String vinNumber;
   private String plate;
   private String idPlusPlate;
   public Auto(String vin, String plate)
   {
      // TODO: Complete the constructor
      super(vin);
      vinNumber = vin;
      this.plate = plate;
   }

   // TODO:  implement the getID() method for autos
   public String getID()
   {
      idPlusPlate = "VIN=" + super.getID() + ",plate=" + this.plate;
      return idPlusPlate;
   }
}