import java.util.Scanner;

/**
   Reads a string and prints out all vowels contained in that string.
   Vowels are A E I O U a e i o u. 

   Input: the value of s, a string
   Output: a string containing all the vowels in s,
      in the order in which they appear in s
*/
public class GetVowels
{
   public static void main(String[] args)
   {
      String r = "";
      String vowels = "AEIOUaeiou";
      
      Scanner in = new Scanner(System.in);
      String s = in.nextLine();

      // your work here
      // define the while arguments
      int i = 0;
      while ( i < s.length())
      { if(vowels.indexOf(s.substring(i, i + 1)) > 0)
            r = r + s.substring(i, i + 1);
            
         i++;}

      System.out.println(r);
   }
}