public class Compressor
{
   public String compressImage(String imageColors)
   {
      // your work here
      int b = 1;
      String r = "";
      imageColors = imageColors + "  ";
      for ( int a = 0 ; a < imageColors.length() - 2 ; a ++ )
         { if (imageColors.substring(a, a  + 1).equals(imageColors.substring(a + 1, a + 2)))
               b ++ ;
           else
               {r = r + b + imageColors.substring(a, a + 1);
               b = 1;}
         }
               
               return r;
      
   } 
}