import java.util.Scanner;

/**
   A program reads in a string, followed by an integer n,
   where the value of the integer should be smaller than the
   length of the string.  The program then prints out the last
   n characters of the string.
*/
public class Strings
{
   public static void main (String[] args)
   {
      // Display prompt for string of characters
      System.out.println("Please enter a string: ");

      // Read string
      Scanner in = new Scanner(System.in);
      String str = in.nextLine();

      // Display prompt for integer n
      System.out.println("Please enter a value for n: ");

      // Read n
      int n = in.nextInt();

      // Print last n characters of string
      //for getting on character which you can just - 1, and of the same as five. Not to thinking contracdictory, be in sequence.
      System.out.println(str.substring(str.length() - n));
      // Your work here


   }
}