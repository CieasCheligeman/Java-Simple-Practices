public class AnimalGreeting
{
    public static void main(String[] args)
   {
      System.out.println(" /\\_/\\      -----\n( ' ' )   / Hello \\\n(  -  )  <  Junior |\n | | |    \\ Coder!/\n(__|__)     -----");

   }
}