import java.util.Scanner;

/** 
   This program reads a student's final class average,
   and prints out the appropriate letter grade.
*/
public class DoGrades
{
   public static void main(String[] args)
   {
      // Print prompt to enter a final class average 
      System.out.println("Enter final class average: ");

      // Read in final class average
      Scanner in = new Scanner(System.in);
      double average = in.nextDouble();

      String finalGrade;

      // Determine and print final grade
      if ( average <= 60 )
      {
         finalGrade = "F";
      }
      else
      {
         if ( average <= 70 )
         {
            finalGrade = "D";
         }
         else
         {
            if ( average <= 80 )
            {
               finalGrade = "C";
            }
            else
            {
               if ( average <= 90 )
               {
                  finalGrade = "B";
               }
               else
               {
                  finalGrade = "A";
               }
            }
         }
      }
     
      // Your work here
      System.out.println(finalGrade);
   }
}