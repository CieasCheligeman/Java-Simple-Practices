public class Moth{
   private double position;
   public Moth (double initialPosition){
      position = initialPosition;
   }
   public void moveToLight(double lightPosition){
      position += (lightPosition - position) / 2.0;
   }
   public double getPosition(){
      return position;
   }
}