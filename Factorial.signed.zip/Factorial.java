import java.util.Scanner;

/**
   Computes n! = 1 x 2 x ... (n - 1) x n, given n.
   We assume n is greater than zero and less than 12.

   Input: n, the integer value for which n! is to be computed.
   Output: n! -- the factorial of n
*/
public class Factorial
{
   public static void main(String[] args)
   {
      // Read value for n
      Scanner in = new Scanner(System.in);
      int n = in.nextInt();
      int a = 1;
      int smoothMoving;

      // your work here
      for ( smoothMoving = 1 ; smoothMoving < n ; smoothMoving ++ )
         { a = a * ( smoothMoving + 1 );}


      System.out.println(a);
   }
}