import java.util.ArrayList;

public class Words
{
   /**
      Returns all short words (length <= 3) in an array of words
      @param words an array of strings
      @return an array list containing the short words in words
   */
   public ArrayList<String> shortWords(String[] words)
   {
      // your work here
      ArrayList<String> wordContainer = new ArrayList<String>();
      for ( int i = 0; i < words.length; i++)
           wordContainer.add(words[i]);    
      for ( int a = wordContainer.size() - 1; a >= 0; a-- )
      {     if ( (wordContainer.get(a)).length() > 3 )
                  wordContainer.remove(a); }
      return wordContainer;
      
      
   }
}