public class PasswordTester
{
   public static void main(String[] args)
   {
      String originalPassword="asecretid";

      // Your work here
      originalPassword = originalPassword.replace("e","3");
      originalPassword = originalPassword.replace("i","1");
      originalPassword = originalPassword.replace("a","@");
      originalPassword = originalPassword.replace("s","$");
      
      String modifiedPassword = originalPassword;
            
      System.out.println(modifiedPassword);
      // Also print out what you expect
      System.out.println("Expected: @$3cr3t1d");
   }
}