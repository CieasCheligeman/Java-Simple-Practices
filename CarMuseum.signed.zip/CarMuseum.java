/**
   Allows input of unique cars into the museum.
*/

// TODO: modify this class to implement the Measurable interface

import java.util.*;

public class CarMuseum implements Measurable
{
   private ArrayList<String> cars;
   public CarMuseum(String input)
   {
      int counter1 = 0;
      cars = new ArrayList<String>();
      // TODO:  complete this method to add
      // cars from the input string.  Only
      // allow unique cars to be added (no
      // duplicates).
      for ( int k = 0; k < input.length(); k ++){
         if ( input.substring(k , k + 1).equals(",")){
            cars.add(input.substring(counter1 , k));
            counter1 = k + 1 ;
         }
      }
      for (int i = cars.size() - 1 ; i >= 0; i --){
         for (int s = 0; s < cars.size(); s ++){
            if ( cars.get(i) == cars.get(s) && s != i){
                  cars.remove(s);
            }
         }
      }
      
   }
   /**
      Returns the count of cars
      @return the count of cars in the museum
   */

   // TODO:  Implement the getMeasure method from the interface
   public double getMeasure(){
      return cars.size();
   }
}